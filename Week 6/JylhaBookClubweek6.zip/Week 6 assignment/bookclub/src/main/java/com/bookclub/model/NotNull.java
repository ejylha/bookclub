package com.bookclub.model;

public @interface NotNull {

    String message();

}
