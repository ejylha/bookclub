package com.bookclub.service.dao;

import com.bookclub.model.Wishlistitem;
import com.bookclub.service.GenericCrudDao;

public interface WishlistDao extends GenericCrudDao<Wishlistitem, String> {
}
