package com.bookclub.model;

public @interface Id {

}
