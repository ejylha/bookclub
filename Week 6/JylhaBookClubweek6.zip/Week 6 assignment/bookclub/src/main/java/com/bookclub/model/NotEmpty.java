package com.bookclub.model;

public @interface NotEmpty {

    String message();

}
